package com.cts.service;

import com.cts.entity.UserLogin;

public interface UserLoginService {

	public void registerUser(UserLogin login);
}

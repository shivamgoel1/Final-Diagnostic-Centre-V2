package com.cts.dao;

import com.cts.entity.UserLogin;

public interface UserLoginDAO {
	
	public void registerUser(UserLogin login );
}
